"""Shared fixtures for task tests."""

# Task protocol is now always enabled - no fixture needed
