"""Deprecated server tests."""
